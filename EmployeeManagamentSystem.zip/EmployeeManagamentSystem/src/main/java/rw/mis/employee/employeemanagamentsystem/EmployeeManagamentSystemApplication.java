package rw.mis.employee.employeemanagamentsystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeManagamentSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(EmployeeManagamentSystemApplication.class, args);
    }

}
